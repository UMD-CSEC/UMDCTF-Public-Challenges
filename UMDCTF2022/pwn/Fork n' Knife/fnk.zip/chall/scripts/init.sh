#!/bin/sh
service cron start
service xinetd start
sleep infinity
