#!/bin/sh
cd /ctf
exec ./fnk
