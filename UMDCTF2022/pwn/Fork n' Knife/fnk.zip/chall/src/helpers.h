#include <sys/types.h>

int get_int(void);
size_t get_line(char *buf, size_t n);
int readn(int fd, void *buf, size_t count);
