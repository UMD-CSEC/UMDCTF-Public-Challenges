<html>
	<head>
		<title>.htaccess luvs me</title>
	</head>
	<body style="background-color:black">
		<div align="center">
		<h1 style="color:white">Nothing to see here, folks. Carry on!</h1>
		<br />
		<img src="http://i0.kym-cdn.com/photos/images/original/001/093/972/50c.jpeg">
		</div>
	</body>
</html>
