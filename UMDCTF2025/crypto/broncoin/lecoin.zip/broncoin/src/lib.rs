pub mod coin;
pub mod hash;
pub mod merkle;
pub mod transact;

pub const DEPTH: usize = 19;
